package com.emp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.emp.bean.Employee;
import com.emp.dao.EmployeeDAOImpl;
import com.emp.dao.IEmployeeDAO;

@Component
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	IEmployeeDAO  employeeDAO;
	
	@Override
	public void addEmployee(Employee emp) {
		
		employeeDAO.addEmployee(emp);
		
	}

}
