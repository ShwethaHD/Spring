package com.emp.dao;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.emp.bean.Employee;

@Component
public class EmployeeDAOImpl implements IEmployeeDAO {
	
	
Map<Integer, Employee> map=new HashMap<Integer, Employee>();
	@Override
	public void addEmployee(Employee emp) {
		
	map.put(emp.getEmployeeID(), emp);
		
	}

}
