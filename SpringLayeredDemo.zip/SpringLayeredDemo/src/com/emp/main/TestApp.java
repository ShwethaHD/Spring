package com.emp.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.emp.bean.Employee;
import com.emp.controller.EmployeeController;

public class TestApp {

	public static void main(String[] args) {
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
		
		EmployeeController controller = (EmployeeController) ctx.getBean("employeeController");
		Employee emp = new Employee();
		emp.setEmployeeID(1001);
		emp.setEmployeeName("john");
		controller.sendEmployee(emp);
		System.out.println("Employee Added Success........ ");
		
		
	}
}
